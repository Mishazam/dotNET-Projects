--*******************************************
--** Creating Books table with some data   **
--*******************************************
CREATE TABLE Books(
bookId INT,
bookname VARCHAR(255),
category VARCHAR(255),
shelfnumber INT,
price INT,
issued VARCHAR(255)
);
INSERT INTO Books
VALUES('1','Mocking Bird', 'Fiction', '1', '200', 'true');
INSERT INTO Books
VALUES('2','As I Lay Dying', 'Fiction', '1', '300', 'true');
INSERT INTO Books
VALUES('3','Beloved', 'Technology', '2', '350', 'false');
INSERT INTO Books
VALUES('4','New World', 'Science', '3', '300', 'true');
INSERT INTO Books
VALUES('5','Moon', 'Science', '3', '350', 'false');
INSERT INTO Books
VALUES('6','Cry Cry', 'Technology', '2', '450', 'true');

--*******************************************
--** Creating Users table with some data   **
--*******************************************
CREATE TABLE Users(
userId INT,
userName VARCHAR(255),
issuedBooks VARCHAR(255),
issueDate date,
fine INT
);
INSERT INTO Users
VALUES('1', 'Peter', 'As I Lay Dying', '2022-11-16', '');
INSERT INTO Users
VALUES('2', 'Max', 'Mocking Bird', '2022-11-09', '');
INSERT INTO Users
VALUES('3', 'Letty', 'New World', '2022-10-29', '');
INSERT INTO Users
VALUES('4', 'Dexter', 'Cry Cry', '2022-10-13', '');

--*******************************************
--**    Procedure to fetch book details    **
--*******************************************
GO
CREATE PROCEDURE get_bookdetails
AS
SELECT * FROM Books;

--*******************************************
--**    Procedure to fetch book details    **
--*******************************************
GO
CREATE PROCEDURE get_userdetails
AS
SELECT * FROM Users;

--*******************************************
--**    Procedure to add new book          **
--*******************************************
GO
CREATE PROCEDURE add_book
@Id INT,
@Name VARCHAR(255),
@Category VARCHAR(255),
@Shelf INT,
@Price INT,
@Issued VARCHAR(255)
AS
INSERT INTO Books
VALUES(@Id, @Name, @Category, @Shelf, @Price, @Issued);

--*******************************************
--**     Procedure to add new user         ** 
--*******************************************
GO
CREATE PROCEDURE add_user
@Id INT,
@Name VARCHAR(255),
@IssuedBooks VARCHAR(255)
AS
INSERT INTO Users
VALUES(@Id, @Name, @IssuedBooks);

--*******************************************
--**     Procedure to update book          ** 
--*******************************************
GO
CREATE PROCEDURE update_book
@Id INT,
@BookName VARCHAR(255),
@Category VARCHAR(255),
@ShelfNumber VARCHAR(255),
@Price INT,
@Issued VARCHAR(255)
AS
UPDATE Books
SET bookname=@BookName, category=@Category, shelfnumber=@ShelfNumber, issued=@Issued
WHERE bookId = @Id;

--*******************************************
--**     Procedure to update user          ** 
--*******************************************
GO
CREATE PROCEDURE update_user
@Id INT,
@UserName VARCHAR(255),
@IssuedBooks VARCHAR(255)
AS
UPDATE Users
SET userName=@UserName, issuedBooks=@IssuedBooks
WHERE userId = @Id;

--*******************************************
--**     Procedure to isuue book           ** 
--*******************************************
GO
CREATE PROCEDURE issue_book
@IssuedBooks VARCHAR(255),
@Issued VARCHAR(255),
@BookName VARCHAR(255),
@UserName VARCHAR(255)
AS
UPDATE Books
SET issued= @Issued
WHERE bookname= @BookName;
UPDATE Users
SET issuedBooks= @IssuedBooks
WHERE userName= @UserName;

--*******************************************
--**    Delete book from Books Table       ** 
--*******************************************
GO
CREATE PROCEDURE delete_book_BookTable
@BookName VARCHAR(255)
AS
DELETE FROM Books
WHERE bookname= @BookName;

--*******************************************
--**    Delete book from Users Table       ** 
--*******************************************
GO
CREATE PROCEDURE delete_book_UserTable
@IssuedBooks VARCHAR(255),
@UserName VARCHAR(255)
AS
UPDATE Users
SET issuedBooks= @IssuedBooks
WHERE userName= @UserName;

--*******************************************
--**    Delete user from Users Table       ** 
--*******************************************
GO
CREATE PROCEDURE delete_user
@UserName VARCHAR(255)
AS
DELETE FROM Users
WHERE userName= @UserName;



--*******************************************
--**  Change issued book from Users Table  ** 
--*******************************************
GO
CREATE PROCEDURE change_issuedbooks_UserTable
@IssuedBook VARCHAR(255),
@UserName VARCHAR(255)
AS
UPDATE Users
SET issuedBooks= @IssuedBook
WHERE userName= @UserName;

--********************************************
--** Change issued status from Books Table  ** 
--********************************************
GO
CREATE PROCEDURE change_issued_BookTable
@Name VARCHAR(255),
@Status VARCHAR(255)
AS
UPDATE Books
SET issued=@Status
WHERE bookname=@Name;

SELECT * FROM Books
SELECT * FROM Users

