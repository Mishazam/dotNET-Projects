﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver.Core.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace dotNet_Assignment_5.DataLayer
{
    public class SQLData
    {
        //Server credentials for establishing connection with server
        string connectionString = @"Data Source=DESKTOP\SQLEXPRESS; Initial Catalog=Bootcamp; Trusted_Connection=True";

        //Fetching books detail from DataBase
        public List<book> GetBooksDetail()
        {
            List<book> Blst = new List<book>();
            SqlConnection cnn;
            cnn = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("get_bookdetails", cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            //Connection open
            cnn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                book temp = new book();

                temp.bookId = Convert.ToInt32(sdr["bookId"]);
                temp.name = sdr["bookname"].ToString();
                temp.price = Convert.ToInt32(sdr["price"]);
                temp.shelfNumber = Convert.ToInt32(sdr["shelfnumber"]);
                temp.category = sdr["category"].ToString();
                temp.issued = sdr["issued"].ToString();
                Blst.Add(temp);
            }
            cnn.Close();
            return Blst;
        }

        //Fetching users detail from DataBase
        public List<user> GetUsersDetail()
        {
            List<user> Ulst = new List<user>();
            SqlConnection cnn;
            cnn = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("get_userdetails", cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            //Connection open
            cnn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                user temp = new user();

                temp.UserId = Convert.ToInt32(sdr["userId"]);
                temp.UserName = sdr["userName"].ToString();
                temp.IssuedBooks = sdr["issuedBooks"].ToString();
                temp.IssueDate = Convert.ToDateTime(sdr["issueDate"]);
                temp.Fine = Convert.ToInt32(sdr["fine"]);
                Ulst.Add(temp);
            }
            cnn.Close();
            return Ulst;
        }

        //------------------------Task 1 Adding new book in list------------------------
        public List<book> AddBook([FromBody] book userInput)
        {
            List<book> Blst = new List<book>();
            Blst = GetBooksDetail();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("add_book", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Id", userInput.bookId);
                cmd.Parameters.AddWithValue("@Name", userInput.name);
                cmd.Parameters.AddWithValue("@Category", userInput.category);
                cmd.Parameters.AddWithValue("@Shelf", userInput.shelfNumber);
                cmd.Parameters.AddWithValue("@Price", userInput.price);
                cmd.Parameters.AddWithValue("@Issued", userInput.issued);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            Blst.Add(userInput);
            return Blst;
        }

        //------------------------Task 2 Adding new user in list------------------------
        public List<user> AddUser([FromBody] user userInput)
        {
            List<user> Ulst = new List<user>();
            Ulst = GetUsersDetail();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("add_user", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Id", userInput.UserId);
                cmd.Parameters.AddWithValue("@Name", userInput.UserName);
                cmd.Parameters.AddWithValue("@IssuedBooks", userInput.IssuedBooks);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            Ulst.Add(userInput);
            return Ulst;
        }

        //------------------------Task 3 Fetching book by name------------------------
        public book getBook(string bookName)
        {
            List<book> Blst = new List<book>();
            Blst = GetBooksDetail();
            book temp = new book();
            foreach (var x in Blst)
            {
                if (x.name == bookName)
                {
                    return x;
                }
            }
            return temp;
        }

        //------------------------Task 4 Fetching user by name------------------------
        public user getUser(string userName)
        {
            List<user> Ulst = new List<user>();
            Ulst = GetUsersDetail();
            user temp = new user();
            foreach (var x in Ulst)
            {
                if (x.UserName == userName)
                {
                    return x;
                }
            }
            return temp;
        }

        //------------------------Task 5 Update book by book ID------------------------
        public List<book> UpdateBook(int bookID, [FromBody] book UpdateInput)
        {
            List<book> Blst = new List<book>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("update_book", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Id", bookID);
                cmd.Parameters.AddWithValue("@BookName", UpdateInput.name);
                cmd.Parameters.AddWithValue("@Category", UpdateInput.category);
                cmd.Parameters.AddWithValue("@ShelfNumber", UpdateInput.shelfNumber);
                cmd.Parameters.AddWithValue("@Price", UpdateInput.price);
                cmd.Parameters.AddWithValue("@Issued", UpdateInput.issued);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            Blst = GetBooksDetail();
            return Blst;
        }

        //------------------------Task 6 Update user by user id------------------------
        public List<user> UpdateUser(int userID, [FromBody] user UpdateInput)
        {
            List<user> Ulst = new List<user>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("update_user", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Id", userID);
                cmd.Parameters.AddWithValue("@UserName", UpdateInput.UserName);
                cmd.Parameters.AddWithValue("@IssuedBooks", UpdateInput.IssuedBooks);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            Ulst = GetUsersDetail();
            return Ulst;
        }

        //------------------------Task 7 Issue new book------------------------
        public List<user> issueBook(string userName, string bookName)
        {
            List<book> Blst = new List<book>();
            List<user> Ulst = new List<user>();
            Blst = GetBooksDetail();
            Ulst = GetUsersDetail();
            foreach (var x in Ulst)
            {
                if (userName == x.UserName)
                {
                    foreach (var y in Blst)
                    {
                        if (y.name == bookName && y.issued == "false")
                        {
                            if (x.IssuedBooks == "")
                            {
                                x.IssuedBooks = bookName;
                            }
                            else
                            {
                                x.IssuedBooks = x.IssuedBooks + ", " + bookName;
                            }
                            y.issued = "true";
                            using (SqlConnection con = new SqlConnection(connectionString))
                            {
                                SqlCommand cmd = new SqlCommand("issue_book", con);
                                cmd.CommandType = CommandType.StoredProcedure;

                                cmd.Parameters.AddWithValue("@IssuedBooks", x.IssuedBooks);
                                cmd.Parameters.AddWithValue("@Issued", y.issued);
                                cmd.Parameters.AddWithValue("@BookName", bookName);
                                cmd.Parameters.AddWithValue("@UserName", userName);

                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }
                            return Ulst;
                        }
                    }
                }
            }
            return Ulst;
        }

        //------------------------Task 8 deleting book------------------------
        public List<book> DeleteBook(string bookName)
        {
            List<book> Blst = new List<book>();
            List<user> Ulst = new List<user>();
            Blst = GetBooksDetail();
            Ulst = GetUsersDetail();
            string tempUserName = "";
            string str = "";
            foreach (var x in Blst)
            {
                if (bookName == x.name)
                {
                    //Deleting from Books table in database
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("delete_book_BookTable", con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@BookName", bookName);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }

                    //Deleting book from Users table in database
                    foreach (var y in Ulst)
                    {
                        string[] temp = y.IssuedBooks.Split(',').Select(sValue => sValue.Trim()).ToArray();
                        for (int i = 0; i < temp.Count(); i++)
                        {
                            if (temp[i] == bookName)
                            {
                                tempUserName = y.UserName;
                                if (temp.Count() <= 1)
                                {
                                    y.IssuedBooks = "";
                                    break;
                                }
                                else
                                {
                                    for (int j = i; j < temp.Count() - 1; j++)
                                    {
                                        //Removing book name from temp array
                                        temp[j] = temp[j + 1];
                                    }
                                    str = string.Join(", ", temp);
                                    y.IssuedBooks = str;
                                }
                            }
                        }
                        using (SqlConnection con = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand("delete_book_UserTable", con);
                            cmd.CommandType = CommandType.StoredProcedure;

                            cmd.Parameters.AddWithValue("@IssuedBooks", y.IssuedBooks);
                            cmd.Parameters.AddWithValue("@UserName", tempUserName);

                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            Blst = GetBooksDetail();
            return Blst;
        }

        //------------------------Task 9 deleting user by name------------------------
        public List<user> DeleteUser(string userName)
        {
            List<book> Blst = new List<book>();
            List<user> Ulst = new List<user>();
            Blst = GetBooksDetail();
            Ulst = GetUsersDetail();
            foreach (var x in Ulst)
            {
                if (userName == x.UserName && x.IssuedBooks == "")
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("delete_user", con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@UserName", userName);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            Ulst = GetUsersDetail();
            return Ulst;
        }

        //------------------------Task 10 returning issued book------------------------
        public List<user> ReturnBook(string userName)
        {
            List<book> Blst = new List<book>();
            List<user> Ulst = new List<user>();
            Blst = GetBooksDetail();
            Ulst = GetUsersDetail();
            foreach (var x in Ulst)
            {
                if (userName == x.UserName)
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("change_issuedbooks_UserTable", con);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@USerName", x.UserName);
                        cmd.Parameters.AddWithValue("@IssuedBook", "");

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    foreach (var y in Blst)
                    {
                        if (x.IssuedBooks == y.name)
                        {
                            using (SqlConnection con = new SqlConnection(connectionString))
                            {
                                SqlCommand cmd = new SqlCommand("change_issued_BookTable", con);
                                cmd.CommandType = CommandType.StoredProcedure;

                                cmd.Parameters.AddWithValue("@Name", y.name);
                                cmd.Parameters.AddWithValue("@Status", "false");

                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }
                        }
                    }
                }
            }
            Ulst = GetUsersDetail();
            return Ulst;
        }

        //------------------------Task 11 calculating fine------------------------
        public List<user> GetFine(string userName)
        {
            List<user> Ulst = new List<user>();
            Ulst = GetUsersDetail();
            int totalFine = 0;
            foreach(var x in Ulst)
            {
                if (userName == x.UserName)
                {
                    if(x.IssueDate != null)
                    {
                        DateTime today = DateTime.Today;
                        var diff = today - x.IssueDate;
                        int temp = diff.Days;
                        int fineDays = temp - 15;

                        if(fineDays!=0)
                        {
                            totalFine = fineDays * 1;
                        }
                        using (SqlConnection con = new SqlConnection(connectionString))
                        {
                            SqlCommand cmd = new SqlCommand("fine_UserTable", con);
                            cmd.CommandType = CommandType.StoredProcedure;

                            cmd.Parameters.AddWithValue("@Name", userName);
                            cmd.Parameters.AddWithValue("@Fine", totalFine);

                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                    
                }
            }
            Ulst = GetUsersDetail();
            return Ulst;
        }
    }
}
