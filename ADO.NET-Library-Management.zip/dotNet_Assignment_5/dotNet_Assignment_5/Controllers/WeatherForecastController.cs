﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using dotNet_Assignment_5.DataLayer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace dotNet_Assignment_5.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        SQLData t = new SQLData(); 
        List<book> booklst = new List<book>(); 
        List<user> userlst = new List<user>();

        private readonly ILogger<WeatherForecastController> _logger;
        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }
        //String details fro establishing connection with server
        string connectionString = @"Data Source=DESKTOP\SQLEXPRESS; Initial Catalog=Bootcamp; Trusted_Connection=True";

        //***Getting Book List on page***
        [HttpGet("getBooks")]
        public List<book> GetBooks()
        {
            booklst = t.GetBooksDetail();
            return booklst;
        }

        //***Getting User List on page***
        [HttpGet("getUsers")]
        public List<user> GetUsers()
        {
            userlst = t.GetUsersDetail();
            return userlst;
        }

        //***TASK 1***
        [HttpPost("addBook")]
        public IEnumerable<book> AddBook([FromBody] book userInput)
        {
            return t.AddBook(userInput);
        }
        
        //***Task 2**
        [HttpPost("addUser")]
        public IEnumerable<user> AddUser([FromBody] user userInput)
        {
            return t.AddUser(userInput);
        }

        //***Task 3***
        [HttpGet("fetchBook/{bookName}")]
        public book getBook(string bookName)
        {
            return t.getBook(bookName);
        }

        //***Task 4***
        [HttpGet("fetchUser/{userName}")]
        public user getUser(string userName)
        {
            return t.getUser(userName);
        }

        //***Task 5***
        [HttpPut("updateBook/{bookID}")]
        public List<book> UpdateBook(int bookID, [FromBody] book UpdateInput)
        {
            return t.UpdateBook(bookID, UpdateInput);
        }

        //***Task 6***
        [HttpPut("updateUser/{userID}")]
        public List<user> UpdateUser(int userID, [FromBody] user UpdateInput)
        {
            return t.UpdateUser(userID, UpdateInput);
        }

        //***Task 7***
        [HttpPut("issueBook/{userName}/{bookName}")]
        public List<user> issueBook(string userName, string bookName)
        {
            return t.issueBook(userName, bookName);
        }

        //***Task 8***
        [HttpDelete("removeBook/{bookName}")]
        public List<book> DeleteBook(string bookName)
        {
            return t.DeleteBook(bookName);
        }

        //***Task 9***
        [HttpDelete("removeUser/{userName}")]
        public List<user> DeleteUser(string userName)
        {
            return t.DeleteUser(userName);
        }

        //***Task 10***
        [HttpDelete("returnBook/{userName}")]
        public List<user> ReturnBook(string userName)
        { 
            return t.ReturnBook(userName);
        }

        //***Task 11***
        [HttpPut("getFine/{userName}")]
        public List<user> GetFine(string userName)
        {
            return t.GetFine(userName);
        }

    }
}
