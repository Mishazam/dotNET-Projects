using System;
using System.Collections.Generic;

namespace dotNet_Assignment_5
{
    public class book
    {
        public int bookId { get; set; }
        public string name { get; set; }
        public string category { get; set; }
        public int shelfNumber { get; set; }
        public int price { get; set; }
        public string issued { get; set;}
    }
    public class user
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string IssuedBooks { get; set; }
        public int Fine { get; set; }
        public DateTime IssueDate { get; set; }
    }
}
